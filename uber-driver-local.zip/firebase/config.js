import {initializeApp} from 'firebase/app'
 


const firebaseConfig = {

    apiKey: "AIzaSyBKG5-vG_pBdRdKHX30UYUF9_F7SOt8Co4",
  
    authDomain: "uber-eats-a4c19.firebaseapp.com",
  
    projectId: "uber-eats-a4c19",
  
    storageBucket: "uber-eats-a4c19.appspot.com",
  
    messagingSenderId: "976827322571",
  
    appId: "1:976827322571:web:8ba517048bb9928f938b4e"
  
  };

  const firebaseApp = initializeApp(firebaseConfig);
  export default firebaseApp;

   
